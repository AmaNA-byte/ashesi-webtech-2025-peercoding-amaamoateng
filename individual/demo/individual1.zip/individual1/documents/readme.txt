================================================================================
STUDENT REGISTRATION SYSTEM - SETUP GUIDE
Web Technologies Activity 03 (Individual Assignment)
================================================================================

WHAT YOU NEED:
--------------
1. XAMPP (Windows/Mac) or MAMP (Mac)
   Download: https://www.apachefriends.org/
2. Web browser (Chrome, Firefox, Safari)

================================================================================
QUICK SETUP
================================================================================

STEP 1: INSTALL XAMPP
----------------------
1. Download and install XAMPP
2. Open XAMPP Control Panel
3. Start "Apache"
4. Start "MySQL"

STEP 2: COPY FILES
------------------
1. Find htdocs folder:
   - Windows: C:\xampp\htdocs\
   - Mac: /Applications/XAMPP/htdocs/

2. Copy "activity_03" folder to htdocs

   Result: htdocs/activity_03/individual/code/

3. OPTIONAL: Add Ashesi Campus Background Image
   - Save an Ashesi campus photo as "ashesi-campus.jpg"
   - Place it in: activity_03/individual/code/
   - The site will use it as background
   - Or comment out line 28-32 in styles.css to remove background

STEP 3: CREATE DATABASE
------------------------
1. Open browser
2. Go to: http://localhost/phpmyadmin
3. Click "Import"
4. Choose file: activity_03/individual/setup/database.sql
5. Click "Go"
6. Success message should appear

STEP 4: OPEN WEBSITE
---------------------
1. Go to: http://localhost/activity_03/individual/code/index.php
2. You should see the homepage

================================================================================
PROJECT FILES
================================================================================

activity_03/individual/code/
├── index.php              Homepage with navigation
├── register.php           Student registration form
├── register_action.php    Process form and save to database
├── student_list.php       Display all students from database
├── db_connect.php         Database connection
└── styles.css             Page styling (Ashesi colors)

================================================================================
HOW TO USE
================================================================================

1. HOMEPAGE (index.php)
   - Click "Register New Student" or "View All Students"

2. REGISTER STUDENT (register.php)
   - Fill in name, email, and program
   - Click "Submit"
   - See confirmation

3. VIEW STUDENTS (student_list.php)
   - See all registered students in a table

================================================================================
TROUBLESHOOTING
================================================================================

PROBLEM: Can't access http://localhost/...
SOLUTION: 
- Check Apache is running in XAMPP
- Make sure files are in htdocs folder

PROBLEM: "Connection failed"
SOLUTION:
- Check MySQL is running in XAMPP
- If using MAMP, change password in db_connect.php to "root"

PROBLEM: "Table doesn't exist"
SOLUTION:
- Import database.sql in phpMyAdmin again

================================================================================
DATABASE INFO
================================================================================

Database: school_db
Table: students
- id (auto increment)
- name (text)
- email (text)
- program (text)
- created_at (timestamp)

================================================================================
REQUIREMENTS MET
================================================================================

✓ Homepage with PHP variables
✓ Registration form (POST method)
✓ Form processing page
✓ Database connection
✓ Display students from database
✓ CSS styling (Ashesi colors)
✓ Clean, beginner-friendly code
✓ Uses mysqli
✓ Proper comments

================================================================================
Good luck! 🎓
================================================================================
