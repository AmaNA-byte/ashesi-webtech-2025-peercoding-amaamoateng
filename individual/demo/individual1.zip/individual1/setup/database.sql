-- Create the database
CREATE DATABASE IF NOT EXISTS school_db;

-- Use the database
USE school_db;

-- Create students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    program VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add some sample students (for testing)
INSERT INTO students (name, email, program) VALUES
('John Doe', 'john.doe@ashesi.edu.gh', 'Computer Science'),
('Jane Smith', 'jane.smith@ashesi.edu.gh', 'Business Administration'),
('Michael Brown', 'michael.brown@ashesi.edu.gh', 'Computer Engineering');
